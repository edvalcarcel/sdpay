package com.centerm.hybridcore.constant;

/**
 * @author wangwenxun
 * @date 2018/9/3
 */
public class SDKConfig {
    /**
     * Log日志打开开关
     */
    public static boolean OpenLog = false;
    /**
     * Log日志的TAG标记
     */
    public static String TAG = "HYBRID_CPAYSDK";
}
